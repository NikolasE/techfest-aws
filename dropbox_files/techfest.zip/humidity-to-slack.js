'use strict';


var AWS = require('aws-sdk');
var url = require('url');
var https = require('https');
var hookUrl, slackChannel;


slackChannel = '';  // Enter the Slack channel to send a message to
hookUrl = "https://hooks.slack.com/services/...."; //Enter your hook 

var postMessage = function(message, callback) {
    var body = JSON.stringify(message);
    var options = url.parse(hookUrl);
    options.method = 'POST';
    options.headers = {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
    };

    var postReq = https.request(options, function(res) {
        var chunks = [];
        res.setEncoding('utf8');
        res.on('data', function(chunk) {
            return chunks.push(chunk);
        });
        res.on('end', function() {
            var body = chunks.join('');
            if (callback) {
                callback({
                    body: body,
                    statusCode: res.statusCode,
                    statusMessage: res.statusMessage
                });
            }
        });
        return res;
    });

    postReq.write(body);
    postReq.end();
};


exports.handler = (event, context, callback) => {

    console.log('Received event:', JSON.stringify(event, null, 2));

   var slackMessage = {
        channel: slackChannel,
        text: "<!channel> Humidity is "+event.state.reported.humidity,
    };

    postMessage(slackMessage, function(response) {
        if (response.statusCode < 400) {
            console.info('Message posted successfully');
            context.succeed();
        } else if (response.statusCode < 500) {
            console.error("Error posting message to Slack API: " + response.statusCode + " - " + response.statusMessage);
            context.succeed();  // Don't retry because the error is due to a problem with the request
        } else {
            // Let Lambda retry
            context.fail("Server error when processing message: " + response.statusCode + " - " + response.statusMessage);
        }
    });

};
